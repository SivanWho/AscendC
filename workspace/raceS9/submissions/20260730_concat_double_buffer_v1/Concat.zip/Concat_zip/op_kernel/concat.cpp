#include "kernel_operator.h"
#include "kernel_operator_list_tensor_intf.h"

using namespace AscendC;

namespace {
constexpr uint32_t kInlineInputLimit = 128;
}

template <typename T>
class KernelConcat {
public:
    __aicore__ inline void Init(GM_ADDR inputList, GM_ADDR output, const ConcatTilingData &t)
    {
        inputList_ = inputList;
        out_.SetGlobalBuffer((__gm__ T *)output);
        inputCount_ = t.inputCount;
        blockDim_ = t.blockDim;
        outer_ = t.outer;
        inner_ = t.inner;
        outputAxis_ = t.outputAxis;
        rowsPerTask_ = t.rowsPerTask;
        rowTaskCount_ = t.rowTaskCount;
        axis_ = t.axis;
        tileElems_ = t.tileBytes / sizeof(T);
        pipe_.InitBuffer(copyQue_, 2, t.tileBytes);
    }

    __aicore__ inline void Process(const ConcatTilingData &t)
    {
        ListTensorDesc list((__gm__ void *)inputList_);
        const uint64_t taskCount = static_cast<uint64_t>(rowTaskCount_) * inputCount_;
        for (uint64_t task = GetBlockIdx(); task < taskCount; task += blockDim_) {
            const uint32_t inputId = static_cast<uint32_t>(task % inputCount_);
            const uint64_t rowTask = task / inputCount_;
            const uint64_t firstOuter = rowTask * rowsPerTask_;
            const uint32_t rowCount = static_cast<uint32_t>(
                (outer_ - firstOuter < rowsPerTask_) ? outer_ - firstOuter : rowsPerTask_);
            uint64_t axisSize = 0;
            uint64_t axisPrefix = 0;
            GetAxisInfo(list, t, inputId, axisSize, axisPrefix);
            const uint64_t count = axisSize * inner_;
            if (count == 0) {
                continue;
            }
            GlobalTensor<T> src;
            src.SetGlobalBuffer((__gm__ T *)list.GetDataPtr<__gm__ uint8_t>(inputId));
            const uint64_t srcBase = firstOuter * count;
            const uint64_t dstBase = (firstOuter * outputAxis_ + axisPrefix) * inner_;
            const uint64_t segmentBytes = count * sizeof(T);
            const uint64_t paddedSegmentBytes = (segmentBytes + 31) / 32 * 32;
            const uint64_t outputGap = (outputAxis_ * inner_ - count) * sizeof(T);

            if (rowCount <= 4095 && segmentBytes <= t.tileBytes &&
                paddedSegmentBytes * rowCount <= t.tileBytes &&
                outputGap <= 0xFFFFFFFFULL) {
                const uint32_t blockBytes = static_cast<uint32_t>(segmentBytes);
                DataCopyExtParams inputParams{static_cast<uint16_t>(rowCount), blockBytes, 0, 0, 0};
                DataCopyPadExtParams<T> pad{false, 0, 0, static_cast<T>(0)};
                LocalTensor<T> local = copyQue_.AllocTensor<T>();
                DataCopyPad(local, src[srcBase], inputParams, pad);
                copyQue_.EnQue(local);
                local = copyQue_.DeQue<T>();
                DataCopyExtParams outputParams{
                    static_cast<uint16_t>(rowCount), blockBytes, 0,
                    static_cast<uint32_t>(outputGap), 0};
                DataCopyPad(out_[dstBase], local, outputParams);
                copyQue_.FreeTensor(local);
                continue;
            }

            for (uint32_t row = 0; row < rowCount; ++row) {
                const uint64_t rowSrcBase = srcBase + static_cast<uint64_t>(row) * count;
                const uint64_t rowDstBase = dstBase + static_cast<uint64_t>(row) * outputAxis_ * inner_;
                for (uint64_t done = 0; done < count; done += tileElems_) {
                    const uint32_t cur = static_cast<uint32_t>(
                        (count - done < tileElems_) ? count - done : tileElems_);
                    DataCopyExtParams p{1, cur * static_cast<uint32_t>(sizeof(T)), 0, 0, 0};
                    DataCopyPadExtParams<T> pad{false, 0, 0, static_cast<T>(0)};
                    LocalTensor<T> local = copyQue_.AllocTensor<T>();
                    DataCopyPad(local, src[rowSrcBase + done], p, pad);
                    copyQue_.EnQue(local);
                    local = copyQue_.DeQue<T>();
                    DataCopyPad(out_[rowDstBase + done], local, p);
                    copyQue_.FreeTensor(local);
                }
            }
        }
    }

private:
    __aicore__ inline void GetAxisInfo(
        ListTensorDesc &list,
        const ConcatTilingData &t,
        uint32_t inputId,
        uint64_t &axisSize,
        uint64_t &axisPrefix)
    {
        if (inputCount_ <= kInlineInputLimit) {
            axisSize = t.axisSizes[inputId];
            axisPrefix = t.axisPrefixes[inputId];
            return;
        }

        uint64_t descShape[8] = {};
        TensorDesc<uint8_t> desc;
        desc.SetShapeAddr(descShape);
        axisPrefix = 0;
        for (uint32_t i = 0; i <= inputId; ++i) {
            list.GetDesc(desc, i);
            const uint64_t currentAxisSize = desc.GetShape(axis_);
            if (i == inputId) {
                axisSize = currentAxisSize;
            } else {
                axisPrefix += currentAxisSize;
            }
        }
    }

    TPipe pipe_;
    TQueBind<QuePosition::VECIN, QuePosition::VECOUT, 2> copyQue_;
    GM_ADDR inputList_;
    GlobalTensor<T> out_;
    uint32_t inputCount_, blockDim_, rowsPerTask_, rowTaskCount_, axis_, tileElems_;
    uint64_t outer_, inner_, outputAxis_;
};

template <typename T>
__aicore__ inline void RunConcat(GM_ADDR inputs, GM_ADDR y, const ConcatTilingData &t)
{
    KernelConcat<T> op;
    op.Init(inputs, y, t);
    op.Process(t);
}

extern "C" __global__ __aicore__ void concat(
    GM_ADDR inputs,
    GM_ADDR y,
    GM_ADDR workspace,
    GM_ADDR tiling)
{
    GET_TILING_DATA(tilingData, tiling);
    if (tilingData.dtypeCode == 0) {
        RunConcat<half>(inputs, y, tilingData);
    } else if (tilingData.dtypeCode == 1) {
        RunConcat<float>(inputs, y, tilingData);
    } else if (tilingData.dtypeCode == 2) {
        RunConcat<int32_t>(inputs, y, tilingData);
    } else {
        RunConcat<int8_t>(inputs, y, tilingData);
    }
}
